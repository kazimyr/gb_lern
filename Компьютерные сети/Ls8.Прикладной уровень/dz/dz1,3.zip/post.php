<html>
<body>
<?php // С помощью суперглобального массива $_POST // выводим принятые значения:
echo "<br/>login = ". $_POST ['login'];
echo "<br/>email = ". $_POST ['email'];?>
</body>
</html>