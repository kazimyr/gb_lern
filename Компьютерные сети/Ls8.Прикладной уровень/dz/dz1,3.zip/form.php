<html>
<body>
<form method="POST" action="post.php"> <!--указание метода GET-->
Login: <input type="text" name="login">
<br> E-mail: <input type="text" name="email">
<br> <input type="submit" value="Отправить">
</form>
</body>
</html>