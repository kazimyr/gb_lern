#include <stdio.h>
#include <math.h>
#include <stdlib.h>

#define ROW 3
#define COL 3
#define TPK 11

void	swap(int *a, int *b)
{
	int c;

	c = *a;
	*a = *b;
	*b = c;
}

void	print_arr(int arr[ROW][COL])
{
	for (int i = 0; i < ROW; i++)
	{
		for (int j = 0; j < COL; j++)
			printf("%d ", arr[i][j]);
		printf("\n");
	}
}

void	sort_buble_2d(int arr[ROW][COL])
{
	for (int k = 0; k < ROW * COL; k++)
	{
		for (int row = 0; row < ROW; row++)
		{
			for (int col = 0; col < COL; col++)
			{
				if (arr[row][col] > arr[row][col + 1] && col + 1 != COL)
					swap(&arr[row][col], &arr[row][col + 1]);
				if (arr[row + 1][0] < arr[row][col] && row + 1 != ROW)
					swap(&arr[row + 1][0], &arr[row][col]);
			}
		}
	}
}

double		f(double num)
{
	return (fabs(num)) + 5 * pow(num, 3);
}

int		main(void)
{
	int		arr[ROW][COL] = {
		{9, 6, 2},
		{5, 7, 4},
		{1, 3, 8}
	};
//	print_arr(arr);
//	sort_buble_2d(arr);
//	printf("\n");
//	print_arr(arr);

	double		array[TPK];
	int		i = 0;
	while (i < TPK)
		scanf("%lf\n\n", &array[i++]);
	for (int i = TPK - 1; i >= 0; i--)
	{
		if ((f(array[i] > 400)))
			printf("%d to large\n", i);
		else
			printf("%lf\n", array[i]);
	}

}
