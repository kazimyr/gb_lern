#include <stdio.h>

int isPrime(int number)
{
    if (number < 0) return 0;
    else if (number % 2 == 0) return number == 2;
    else
    {
        int d = 3;
        while (d * d <= number)
        {
            if (number % d == 0) return 0;
            else d += 2;
        }
        return 1;
    }
}

int main()
{
    printf("Input the number: ");
    int num;
    scanf("%d", &num);
    if (isPrime(num)) printf("The number %d is prime.\n", num);
    else printf("The number %d is composite.\n", num);
}
